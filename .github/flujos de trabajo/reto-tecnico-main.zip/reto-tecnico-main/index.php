<?php

echo "<h1>HOLA MUNDO!</h1>";
phpinfo();
